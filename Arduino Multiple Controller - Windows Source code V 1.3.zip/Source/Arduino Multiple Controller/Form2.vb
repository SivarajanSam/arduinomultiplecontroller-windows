﻿Public Class Form2
    Dim s As String
    Dim t As String
    Dim SAPI As Object = CreateObject("sapi.spvoice")
    Private Sub Form2_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Panel1.BackColor = My.Settings.mycolor
        Label1.ForeColor = Color.White
        Label4.ForeColor = Color.White
        Label5.ForeColor = Color.White
        Label6.ForeColor = Color.White
        Button1.ForeColor = Color.White
        Button2.ForeColor = Color.White
        Button3.ForeColor = Color.White
        Panel2.BackColor = My.Settings.mycolor
        Panel3.BackColor = My.Settings.mycolor
        Panel4.BackColor = My.Settings.mycolor
        ComboBox1.BackColor = My.Settings.mycolor
        If My.Computer.Network.IsAvailable Then
            ComboBox1.Items.Add(My.Settings.d1)
            ComboBox1.Items.Add(My.Settings.d2)
            ComboBox1.Items.Add(My.Settings.d3)
            ComboBox1.Items.Add(My.Settings.d4)
            ComboBox1.Items.Add(My.Settings.d5)
            ComboBox1.Items.Add(My.Settings.d6)
        Else
            MsgBox(" Your computer is not connected to internet.", MsgBoxStyle.Critical, "Error")
            SAPI.Speak("Your computer is not connected to internet")
            Me.Close()
        End If

    End Sub
    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        s = TextBox1.Text & "?" & ComboBox1.Text & "=on"
        chkurl()
    End Sub
    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        s = TextBox1.Text & "?" & ComboBox1.Text & "=off"
        chkurl()
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        s = TextBox1.Text & "?" & ComboBox1.Text & TextBox2.Text
        chkurl()
    End Sub
    Private Sub chkurl()
        WebBrowser1.Navigate(s)
    End Sub

    Private Sub TrackBar1_Scroll(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TrackBar1.Scroll
        s = TextBox1.Text & "?" & ComboBox1.Text & TrackBar1.Value
        chkurl()
    End Sub

End Class