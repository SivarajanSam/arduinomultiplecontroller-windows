﻿Public Class Form1
    Dim SAPI As Object = CreateObject("sapi.spvoice")
    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        SAPI.Speak("Hello developer")
        Me.WindowState = FormWindowState.Maximized
    End Sub
    Private Sub SettingsToolStripMenuItem1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SettingsToolStripMenuItem1.Click
        Form6.WindowState = FormWindowState.Maximized
        Form6.MdiParent = Me
        Form6.Show()
    End Sub

    Private Sub HomeAutomationWebToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles HomeAutomationWebToolStripMenuItem.Click
        Form2.WindowState = FormWindowState.Maximized
        Form2.Show()
        Form2.MdiParent = Me
    End Sub

    Private Sub ButtonToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ButtonToolStripMenuItem.Click
        Form3.WindowState = FormWindowState.Maximized
        Form3.Show()
        Form3.MdiParent = Me
    End Sub

    Private Sub VoiceToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles VoiceToolStripMenuItem.Click
        Form4.WindowState = FormWindowState.Maximized
        Form4.Show()
        Form4.MdiParent = Me
    End Sub

    Private Sub CommandToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CommandToolStripMenuItem.Click
        Form5.WindowState = FormWindowState.Maximized
        Form5.Show()
        Form5.MdiParent = Me
    End Sub

    Private Sub HelpToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles HelpToolStripMenuItem.Click
        Form7.Show()
    End Sub

    Private Sub AboutUsToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AboutUsToolStripMenuItem.Click
        about.Show()
    End Sub

    Private Sub MenuStrip1_ItemClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.ToolStripItemClickedEventArgs) Handles MenuStrip1.ItemClicked

    End Sub
End Class
